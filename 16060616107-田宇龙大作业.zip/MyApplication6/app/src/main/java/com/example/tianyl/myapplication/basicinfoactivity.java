package com.example.tianyl.myapplication;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
public class basicinfoactivity extends AppCompatActivity {
    textservice yanzhenservice;
    String shuzu[] = new String[8];
    private ServiceConnection service1 = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            yanzhenservice = (textservice) ((textservice.LocalBinder) service).getService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basicinfoactivity);
        final EditText stu_id = findViewById(R.id.stu_id);
        final EditText name_id = findViewById(R.id.name_id);
        final EditText shenfen_id = findViewById(R.id.shenfen_id);
        RadioGroup radio1 = findViewById(R.id.radio1);
        final EditText jiguan_id = findViewById(R.id.jiguan_id);
        final EditText year_id = findViewById(R.id.year_id);
        final EditText month_id = findViewById(R.id.month_id);
        final EditText day_id = findViewById(R.id.day_id);
        final Intent service2 = new Intent(this, textservice.class);
        bindService(service2, service1, basicinfoactivity.BIND_AUTO_CREATE);
        shenfen_id.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if (shenfen_id.getText().toString().length() >= 17) {
                    shuzu[4] = yanzhenservice.getNative(shenfen_id.getText().toString());
                    shuzu[5] = yanzhenservice.birthday(shenfen_id.getText().toString())[0];
                    shuzu[6] = yanzhenservice.birthday(shenfen_id.getText().toString())[1];
                    shuzu[7] = yanzhenservice.birthday(shenfen_id.getText().toString())[2];
                    jiguan_id.setText(yanzhenservice.getNative(shenfen_id.getText().toString()));
                    year_id.setText(yanzhenservice.birthday(shenfen_id.getText().toString())[0]);
                    month_id.setText(yanzhenservice.birthday(shenfen_id.getText().toString())[1]);
                    day_id.setText(yanzhenservice.birthday(shenfen_id.getText().toString())[2]);
                }

            }
        });
        radio1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int radio_id1=group.getCheckedRadioButtonId();
                RadioButton choice=basicinfoactivity.this.findViewById(radio_id1);
                shuzu[3]=choice.getText().toString();
            }
        });
        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shuzu[0] = stu_id.getText().toString();
                shuzu[1] = name_id.getText().toString();
                shuzu[2] = shenfen_id.getText().toString();
                Intent intent = new Intent(basicinfoactivity.this, schoolinfoactivity.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("shuzu", shuzu);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
