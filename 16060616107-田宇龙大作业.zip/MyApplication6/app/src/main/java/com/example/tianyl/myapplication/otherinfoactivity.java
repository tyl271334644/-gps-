package com.example.tianyl.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
public class otherinfoactivity  extends AppCompatActivity {
    CheckBox[] choice = new CheckBox[6];
    String[] shuzu;
    EditText phone_id;
    EditText email_id;
    EditText wechat_id;
    String getchoice;
    String major;
    String class1;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 10) {
            if (Build.VERSION.SDK_INT >= 23) {
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "拒绝权限", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otherinfoactivity);
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(otherinfoactivity.this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 10);
            }
        }
        Bundle bundle = this.getIntent().getExtras();
        shuzu = bundle.getStringArray("shuzu");
        getchoice = bundle.getString("getchoice");
        major = bundle.getString("major");
        class1 = bundle.getString("class1");
        choice[0] = findViewById(R.id.checkbox1);
        choice[1] = findViewById(R.id.checkbox2);
        choice[2] = findViewById(R.id.checkbox3);
        choice[3] = findViewById(R.id.checkbox4);
        choice[4] = findViewById(R.id.checkbox5);
        choice[5] = findViewById(R.id.checkbox6);
        phone_id = findViewById(R.id.phone_id);
        email_id = findViewById(R.id.email_id);
        wechat_id = findViewById(R.id.wechat_id);
        Button button4 =  findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("com.example.androidwork");
                intent.setPackage(getPackageName());
                intent.putExtra("info",list());
                sendBroadcast(intent);
            }
        });
    }
    private  String list(){
        String info = " ";
        String check = " ";
        info= "学号：" + shuzu[0] + "\n" +
                "姓名：" + shuzu[1] + "\n" +
                "身份证号：" + shuzu[2] + "\n" +
                "性别：" + shuzu[3] + "\n" +
                "籍贯：" + shuzu[4] + "\n"+
                "生日：" + shuzu[5] +
                "年"+ shuzu[6] + "月" + shuzu[7] + "日\n";
        for (int i = 0; i < choice.length; i++){
            if (choice[i].isChecked()){
                check = check + choice[i].getText().toString() + ",";
            }
        }
        check = check.substring(0, check.length() - 1);
        return info + getchoice + major + class1 + "电话："+phone_id.getText().toString() + "\n" +
                "邮箱：" + email_id.getText().toString() + "\n" +
                "微信号：" + wechat_id.getText().toString() + "\n" +
                "特长：" + check;
    }
}