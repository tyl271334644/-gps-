package com.example.tianyl.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.List;
public class schoolinfoactivity extends AppCompatActivity {
    String[] shuzu;
    String getchoice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schoolinfoactivity);
        Spinner spinner=findViewById(R.id.Spinner);
        List<String> list=new ArrayList<String>();
        list.add("光电工程学院");
        list.add("机电工程学院");
        list.add("材料与化学工程学院");
        list.add("电子信息工程学院");
        list.add("经济管理学院");
        list.add("计算机科学与工程学院");
        list.add("建筑工程学院");
        list.add("外国语学院");
        list.add("人文学院");
        list.add("理学院");
        list.add("体育学院");
        list.add("艺术与传媒学院");
        list.add("中国书法学院");
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        Bundle bundle=this.getIntent().getExtras();
        shuzu=bundle.getStringArray("shuzu");
        final  Spinner spinner1=findViewById(R.id.Spinner);
        final EditText major=findViewById(R.id.major);
        final EditText class1=findViewById(R.id.class1);
        Button button3=findViewById(R.id.button3);
        getchoice=spinner.getSelectedItem().toString();
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(schoolinfoactivity.this, otherinfoactivity.class);
                Bundle bundle = new Bundle();
                bundle.putStringArray("shuzu", shuzu);
                bundle.putString("getchoice", "所在学院：" + getchoice +"\n");
                bundle.putString("major", "专业：" + major.getText().toString() + "\n");
                bundle.putString("class1", "班级：" + class1.getText().toString() + "\n");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
