package com.example.tianyl.myapplication;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
public class textservice extends Service {
    public textservice() {
    }
        private final IBinder mBinder = new LocalBinder();
        public class LocalBinder extends Binder {
            Service getService() {
                return textservice.this;
            }
        }
        @Override
        public IBinder onBind(Intent intent) {
            Toast.makeText(this, "本地绑定", Toast.LENGTH_SHORT).show();
            return mBinder;
        }
        public boolean checkingNumber(String number){
            int[] checkNumber = {7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2};
            String[] lastNumber = {"1","0","x","9","8","7","6","5","4","3","2"};
            int sum = 0;
            int tem = 0;
            if (number.length() >= 17){
                for (int i = 0; i < checkNumber.length; i++){
                    sum += Integer.parseInt(number.charAt(i) + "") * checkNumber[i];
                }
                tem = sum % 11;
                if (tem >=0 && tem <= 10){
                    if(lastNumber[tem].equals(number.charAt(17)+"")){
                        return true;
                    } else return false;
                }
            }
            return false;
        }
        public String[] birthday (String numberId){
            String year = numberId.substring(6, 10);
            String month = numberId.substring(10, 12);
            String day = numberId.substring(12, 14);
            return new String[]{year, month, day};
        }
        public String getNative(String number){
            try {
                InputStream is = getResources().openRawResource(R.raw.native_place_comparison_table);
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String str_raw = "";
                while ((str_raw = br.readLine()) != null) {
                    String[] tem = str_raw.split(":");
                    if (tem[0].equals(number.substring(0,6))){
                        return tem[1];
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return "没找到";
        }
    }
