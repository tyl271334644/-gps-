package com.example.gps_map;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.tencent.map.geolocation.TencentLocation;
import com.tencent.map.geolocation.TencentLocationListener;
import com.tencent.map.geolocation.TencentLocationManager;
import com.tencent.map.geolocation.TencentLocationRequest;
import com.tencent.mapsdk.raster.model.BitmapDescriptorFactory;
import com.tencent.mapsdk.raster.model.Circle;
import com.tencent.mapsdk.raster.model.CircleOptions;
import com.tencent.mapsdk.raster.model.LatLng;
import com.tencent.mapsdk.raster.model.Marker;
import com.tencent.mapsdk.raster.model.MarkerOptions;
import com.tencent.mapsdk.raster.model.Polyline;
import com.tencent.mapsdk.raster.model.PolylineOptions;
import com.tencent.tencentmap.mapsdk.map.MapView;
import com.tencent.tencentmap.mapsdk.map.TencentMap;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity implements TencentLocationListener {
    private Marker myLocation;
    private Circle accuracy;
    private TencentMap tencentMap = null;
    private MapView mapView = null;
    private TencentLocationManager locationManager;
    private TencentLocationRequest locationRequest;
    private ArrayList<LatLng> latLngs = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mapView=(MapView)findViewById(R.id.mapview);
        tencentMap = mapView.getMap();
        tencentMap.setZoom(18);
        locationManager = TencentLocationManager.getInstance(this);
        locationRequest = TencentLocationRequest.create();
        if (Build.VERSION.SDK_INT >= 23) {
            String[] permissions = {
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            };

            if (checkSelfPermission(permissions[0]) != PackageManager.PERMISSION_GRANTED)
            {
                requestPermissions(permissions, 0);
            }
        }
        //获取TencentMap实例
//      测试 定点定位功能
//        LatLng latLng = new LatLng(34.376184,108.987052);
//        tencentMap.setCenter(latLng);
//        Marker marker = tencentMap.addMarker(new MarkerOptions()
//                .position(latLng)
//                .title("西安工业大学(未央校区)")
//                .anchor(0.5f, 0.5f)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker())
//                .draggable(true));
//        marker.showInfoWindow();// 设置默认显示一个infoWindow
//        Marker marker2 = tencentMap.addMarker(new MarkerOptions()
//                .position(new LatLng(34.381435,108.987615))
//                .title("西安工业大学(未央校区)")
//                .anchor(0.5f, 0.5f)
//                .icon(BitmapDescriptorFactory
//                        .defaultMarker())
//                .draggable(true));
//        marker2.showInfoWindow();// 设置默认显示一个infoWindow

        int error = locationManager.requestLocationUpdates(
                locationRequest,MainActivity.this);


    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String[] permissions,  int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(TencentLocation arg0, int arg1, String arg2) {
        // TODO Auto-generated method stub
        if (arg1 == TencentLocation.ERROR_OK) {
            LatLng latLng = new LatLng(arg0.getLatitude(), arg0.getLongitude());
            if (myLocation == null) {
                if(tencentMap==null)Log.e("hfghgf", "onCreate: "+"123");
                myLocation = tencentMap.addMarker(new MarkerOptions().
                        position(latLng).
                        icon(BitmapDescriptorFactory.fromResource(R.mipmap.navigation)).
                        anchor(0.5f, 0.5f));
            }
            if (accuracy == null) {
                accuracy = tencentMap.addCircle(new CircleOptions().
                        center(latLng).
                        radius((double)arg0.getAccuracy()).
                        fillColor(0x440000ff).
                        strokeWidth(0f));
            }
            latLngs.add(latLng);
            Polyline polyline = tencentMap.addPolyline(new PolylineOptions().
                    addAll(latLngs).
                    color(0xff0066cc).
                    width(10f).
                    //为 polyline 添加纹理, 通常用于标记路线
                            arrowTexture(BitmapDescriptorFactory.fromResource(R.mipmap.texture_arrow)).
                            arrowGap(30).
                            edgeColor(0xff0072E3).
                            edgeWidth(5));
            tencentMap.setCenter(latLng);
            myLocation.setPosition(latLng);
            myLocation.setRotation(arg0.getBearing()); //仅当定位来源于gps有效，或者使用方向传感器
            accuracy.setCenter(latLng);
            accuracy.setRadius(arg0.getAccuracy());
        } else {
            Log.e("location", "location failed:" + arg2);
        }
    }

    @Override
    public void onStatusUpdate(String arg0, int arg1, String arg2) {
        // TODO Auto-generated method stub
        String desc = "";
        switch (arg1) {
            case STATUS_DENIED:
                desc = "权限被禁止";
                break;
            case STATUS_DISABLED:
                desc = "模块关闭";
                break;
            case STATUS_ENABLED:
                desc = "模块开启";
                break;
            case STATUS_GPS_AVAILABLE:
                desc = "GPS可用，代表GPS开关打开，且搜星定位成功";
                break;
            case STATUS_GPS_UNAVAILABLE:
                desc = "GPS不可用，可能 gps 权限被禁止或无法成功搜星";
                break;
            case STATUS_LOCATION_SWITCH_OFF:
                desc = "位置信息开关关闭，在android M系统中，此时禁止进行wifi扫描";
                break;
            case STATUS_UNKNOWN:
                break;
        }
        Log.e("location", "location status:" + arg0 + ", " + arg2 + " " + desc);
    }
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        locationManager.removeUpdates(this);
    }


}
